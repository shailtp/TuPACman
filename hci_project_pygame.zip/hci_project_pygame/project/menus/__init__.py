

from project.menus.menu import *
from project.menus.loadgame import *
